# История Git — stage4

3adcb9d stage 1: implement REPL
4e0ffa5 stage 2: add CLI configuration and startup scripts
613193c stage 3: implement in-memory VFS and vfs-save
6139a38 stage 4: add ls cd tree and uname modes

Просмотр: git log --oneline --decorate --graph
