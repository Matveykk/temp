package ru.mirea.variant3;

/** Этап 1: точка входа в минимальный REPL. */
public class Main {
    public static void main(String[] args) throws Exception {
        new Shell().run();
    }
}
