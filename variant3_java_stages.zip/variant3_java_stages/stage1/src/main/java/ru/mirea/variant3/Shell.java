package ru.mirea.variant3;

import java.io.*;
import java.net.InetAddress;
import java.util.*;

/** Этап 1: REPL, prompt, parser, ls/cd/exit. */
public class Shell {
    private boolean running = true;
    private String cwd = "~";

    public void run() throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        while (running) {
            System.out.print(prompt());
            String line = reader.readLine();
            if (line == null) break;
            execute(line);
        }
    }

    private String prompt() {
        String user = System.getProperty("user.name", "user");
        String host;
        try { host = InetAddress.getLocalHost().getHostName(); }
        catch (Exception e) { host = "localhost"; }
        return user + "@" + host + ":" + cwd + "$ ";
    }

    private void execute(String line) {
        List<String> a = parse(line);
        if (a.isEmpty()) return;
        switch (a.get(0)) {
            case "ls" -> System.out.println("(stage 1 stub) current directory: " + cwd);
            case "cd" -> {
                if (a.size() != 2) System.out.println("Error: Usage: cd PATH");
                else cwd = a.get(1);
            }
            case "exit" -> running = false;
            default -> System.out.println("Error: Unknown command: " + a.get(0));
        }
    }

    /** Парсер поддерживает аргументы в одинарных и двойных кавычках. */
    private List<String> parse(String line) {
        List<String> result = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        Character quote = null;
        for (char c : line.toCharArray()) {
            if (quote != null) {
                if (c == quote) quote = null; else cur.append(c);
            } else if (c == '\'' || c == '"') quote = c;
            else if (Character.isWhitespace(c)) { if (!cur.isEmpty()) { result.add(cur.toString()); cur.setLength(0); } }
            else cur.append(c);
        }
        if (!cur.isEmpty()) result.add(cur.toString());
        return result;
    }
}
