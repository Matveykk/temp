# История Git — stage1

652cf76 stage 1: implement REPL

Просмотр: git log --oneline --decorate --graph
