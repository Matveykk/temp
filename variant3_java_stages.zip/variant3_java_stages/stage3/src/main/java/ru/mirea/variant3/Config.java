package ru.mirea.variant3;

import java.nio.file.Path;

/** Параметры запуска эмулятора. */
public record Config(Path vfsPath, Path scriptPath, boolean debug) {
    public static Config parse(String[] args) {
        Path vfs = null;
        Path script = null;
        boolean debug = false;

        for (int i = 0; i < args.length; i++) {
            switch (args[i]) {
                case "--vfs" -> {
                    if (++i >= args.length) throw new EmulatorException("После --vfs нужен путь");
                    vfs = Path.of(args[i]);
                }
                case "--script" -> {
                    if (++i >= args.length) throw new EmulatorException("После --script нужен путь");
                    script = Path.of(args[i]);
                }
                case "--debug" -> debug = true;
                case "--help" -> {
                    System.out.println("Usage: java -jar variant3-emulator-1.0.0.jar [--vfs PATH] [--script PATH] [--debug]");
                    System.exit(0);
                }
                default -> throw new EmulatorException("Неизвестный параметр: " + args[i]);
            }
        }
        if (vfs == null) vfs = Path.of("vfs/files.json");
        return new Config(vfs, script, debug);
    }
}
