package ru.mirea.variant3;

import java.io.*;
import java.net.InetAddress;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/** REPL и команды UNIX-подобной оболочки. */
public class Shell {
    private final Vfs vfs;
    private String cwd = "/";
    private boolean running = true;

    public Shell(Vfs vfs) {
        this.vfs = vfs;
    }

    public void runInteractive() throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        while (running) {
            System.out.print(prompt());
            String line = reader.readLine();
            if (line == null) break;
            executeLine(line);
        }
    }

    public void runScript(Path script) throws IOException {
        for (String line : Files.readAllLines(script)) {
            if (line.isBlank() || line.trim().startsWith("#")) continue;
            System.out.println("$ " + line);
            executeLine(line);
        }
    }

    private String prompt() {
        String user = System.getProperty("user.name", "user");
        String host;
        try {
            host = InetAddress.getLocalHost().getHostName();
        } catch (Exception e) {
            host = "localhost";
        }
        return user + "@" + host + ":" + cwd + "$ ";
    }

    public void executeLine(String line) {
        List<String> args = parse(line);
        if (args.isEmpty()) return;

        String command = args.get(0);
        try {
            switch (command) {
                case "ls" -> ls(args);
                case "cd" -> cd(args);
                case "tree" -> tree(args);
                case "uname" -> uname(args);
                case "cp" -> cp(args);
                case "chmod" -> chmod(args);
                case "vfs-save" -> save(args);
                case "help" -> help();
                case "exit" -> running = false;
                default -> throw new EmulatorException("Unknown command: " + command);
            }
        } catch (EmulatorException e) {
            System.out.println("Error: " + e.getMessage());
            if (Thread.currentThread().getStackTrace().length > 0) {
                // Ошибка выводится пользователю; при запуске скрипта исключение
                // не скрывается, поэтому следующая строка не должна выполняться.
            }
            if (scriptMode) throw e;
        }
    }

    private boolean scriptMode = false;

    private List<String> parse(String line) {
        List<String> result = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        Character quote = null;
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (quote != null) {
                if (c == quote) quote = null;
                else current.append(c);
            } else if (c == '\'' || c == '"') {
                quote = c;
            } else if (Character.isWhitespace(c)) {
                if (!current.isEmpty()) { result.add(current.toString()); current.setLength(0); }
            } else current.append(c);
        }
        if (quote != null) throw new EmulatorException("Незакрытая кавычка");
        if (!current.isEmpty()) result.add(current.toString());
        return result;
    }

    private void require(List<String> args, int n, String usage) {
        if (args.size() != n) throw new EmulatorException("Usage: " + usage);
    }

    private void ls(List<String> args) {
        if (args.size() > 2) throw new EmulatorException("Usage: ls [-l] [PATH]");
        boolean longMode = args.size() == 2 && args.get(1).equals("-l");
        if (args.size() == 2 && !longMode) {
            VfsNode node = vfs.get(cwd, args.get(1));
            printNode(node, longMode);
            return;
        }
        VfsNode dir = vfs.get(cwd, cwd);
        if (!dir.isDirectory()) throw new EmulatorException("Текущий путь не является каталогом");
        for (VfsNode node : dir.getChildren().values()) {
            printNode(node, longMode);
        }
    }

    private void printNode(VfsNode node, boolean longMode) {
        if (longMode) System.out.printf("%s %s%n", modeString(node), node.getName());
        else System.out.println(node.getName());
    }

    private String modeString(VfsNode node) {
        int m = node.getMode();
        return (node.isDirectory() ? "d" : "-")
                + ((m & 400) != 0 ? "r" : "-")
                + ((m & 200) != 0 ? "w" : "-")
                + ((m & 100) != 0 ? "x" : "-")
                + ((m & 40) != 0 ? "r" : "-")
                + ((m & 20) != 0 ? "w" : "-")
                + ((m & 10) != 0 ? "x" : "-")
                + ((m & 4) != 0 ? "r" : "-")
                + ((m & 2) != 0 ? "w" : "-")
                + ((m & 1) != 0 ? "x" : "-");
    }

    private void cd(List<String> args) {
        require(args, 2, "cd PATH");
        VfsNode target = vfs.get(cwd, args.get(1));
        if (!target.isDirectory()) throw new EmulatorException("Не каталог: " + args.get(1));
        cwd = vfs.normalize(cwd, args.get(1));
    }

    private void tree(List<String> args) {
        require(args, 2, "tree PATH");
        VfsNode node = vfs.get(cwd, args.get(1));
        System.out.println(node.getName().equals("/") ? "/" : node.getName());
        treeRecursive(node, "");
    }

    private void treeRecursive(VfsNode node, String prefix) {
        for (VfsNode child : node.getChildren().values()) {
            System.out.println(prefix + "├── " + child.getName());
            if (child.isDirectory()) treeRecursive(child, prefix + "│   ");
        }
    }

    private void uname(List<String> args) {
        if (args.size() > 2) throw new EmulatorException("Usage: uname [-a]");
        if (args.size() == 1) System.out.println("Variant3-UNIX");
        else if (args.get(1).equals("-a")) {
            System.out.println("Variant3-UNIX " + System.getProperty("os.name") + " " + System.getProperty("os.arch"));
        } else throw new EmulatorException("Unknown uname option: " + args.get(1));
    }

    private void cp(List<String> args) {
        require(args, 3, "cp SOURCE DEST");
        vfs.copy(cwd, args.get(1), args.get(2));
    }

    private void chmod(List<String> args) {
        require(args, 3, "chmod MODE PATH");
        int mode;
        try { mode = Integer.parseInt(args.get(1)); }
        catch (NumberFormatException e) { throw new EmulatorException("Некорректный mode"); }
        if (mode < 0 || mode > 777) throw new EmulatorException("Mode должен быть от 000 до 777");
        vfs.chmod(cwd, mode, args.get(2));
    }

    private void save(List<String> args) {
        require(args, 2, "vfs-save PATH");
        try { vfs.save(Path.of(args.get(1))); }
        catch (IOException e) { throw new EmulatorException("Не удалось сохранить VFS: " + e.getMessage()); }
    }

    private void help() {
        System.out.println("ls, cd, tree, uname, cp, chmod, vfs-save, help, exit");
    }

    public void setScriptMode(boolean value) {
        this.scriptMode = value;
    }
}
