package ru.mirea.variant3;

/** Исключение предметной области эмулятора оболочки. */
public class EmulatorException extends RuntimeException {
    public EmulatorException(String message) {
        super(message);
    }
}
