package ru.mirea.variant3;

import java.util.LinkedHashMap;
import java.util.Map;

/** Узел виртуальной файловой системы: файл или каталог. */
public class VfsNode {
    private String name;
    private final boolean directory;
    private String content;
    private int mode;
    private final Map<String, VfsNode> children = new LinkedHashMap<>();

    public VfsNode(String name, boolean directory, String content, int mode) {
        this.name = name;
        this.directory = directory;
        this.content = content == null ? "" : content;
        this.mode = mode;
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public boolean isDirectory() { return directory; }
    public String getContent() { return content; }
    public void setContent(String content) { this.content = content == null ? "" : content; }
    public int getMode() { return mode; }
    public void setMode(int mode) { this.mode = mode; }
    public Map<String, VfsNode> getChildren() { return children; }
    public void addChild(VfsNode node) { children.put(node.getName(), node); }
}
