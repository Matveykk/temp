package ru.mirea.variant3;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.Base64;

/**
 * Виртуальная файловая система.
 *
 * Важная особенность проекта: после загрузки JSON все операции выполняются
 * над объектами Java в памяти. Реальная файловая система ОС не используется
 * командами ls/cd/cp/chmod.
 */
public class Vfs {
    private final VfsNode root;

    public Vfs(VfsNode root) {
        this.root = root;
    }

    public VfsNode getRoot() {
        return root;
    }

    public static Vfs load(Path path) throws IOException {
        String json = Files.readString(path, StandardCharsets.UTF_8);
        Object parsed = new JsonParser(json).parse();
        if (!(parsed instanceof Map<?, ?> map)) {
            throw new EmulatorException("VFS JSON должен содержать объект");
        }
        VfsNode root = nodeFromJson(map, "/");
        return new Vfs(root);
    }

    @SuppressWarnings("unchecked")
    private static VfsNode nodeFromJson(Map<?, ?> map, String defaultName) {
        String name = String.valueOf(map.getOrDefault("name", defaultName));
        boolean directory = Boolean.parseBoolean(String.valueOf(map.getOrDefault("directory", false)));
        int mode = Integer.parseInt(String.valueOf(map.getOrDefault("mode", directory ? 755 : 644)));
        String content = String.valueOf(map.getOrDefault("content", ""));
        if (map.containsKey("content_base64")) {
            content = new String(Base64.getDecoder().decode(String.valueOf(map.get("content_base64"))), StandardCharsets.UTF_8);
        }
        VfsNode node = new VfsNode(name, directory, content, mode);
        Object children = map.get("children");
        if (children instanceof List<?> list) {
            for (Object item : list) {
                if (item instanceof Map<?, ?> childMap) {
                    node.addChild(nodeFromJson(childMap, ""));
                }
            }
        }
        return node;
    }

    /** Нормализует абсолютный/относительный виртуальный путь. */
    public String normalize(String cwd, String input) {
        String raw = input.startsWith("/") ? input : (cwd.equals("/") ? "/" + input : cwd + "/" + input);
        Deque<String> parts = new ArrayDeque<>();
        for (String part : raw.split("/")) {
            if (part.isEmpty() || part.equals(".")) continue;
            if (part.equals("..")) {
                if (!parts.isEmpty()) parts.removeLast();
            } else {
                parts.addLast(part);
            }
        }
        return "/" + String.join("/", parts);
    }

    public VfsNode get(String cwd, String path) {
        String normalized = normalize(cwd, path);
        if (normalized.equals("/")) return root;
        VfsNode current = root;
        for (String part : normalized.substring(1).split("/")) {
            if (!current.isDirectory() || !current.getChildren().containsKey(part)) {
                throw new EmulatorException("Путь не найден: " + path);
            }
            current = current.getChildren().get(part);
        }
        return current;
    }

    public VfsNode parentOf(String cwd, String path) {
        String normalized = normalize(cwd, path);
        if (normalized.equals("/")) throw new EmulatorException("У корня нет родителя");
        int slash = normalized.lastIndexOf('/');
        return get("/", slash == 0 ? "/" : normalized.substring(0, slash));
    }

    public void copy(String cwd, String source, String destination) {
        VfsNode src = get(cwd, source);
        String normalized = normalize(cwd, destination);
        if (normalized.equals("/")) throw new EmulatorException("Нельзя заменить корень");
        int slash = normalized.lastIndexOf('/');
        VfsNode parent = get("/", slash == 0 ? "/" : normalized.substring(0, slash));
        if (!parent.isDirectory()) throw new EmulatorException("Назначение не является каталогом");
        String name = normalized.substring(slash + 1);
        if (name.isBlank()) throw new EmulatorException("Некорректное имя назначения");
        parent.getChildren().put(name, deepCopy(src, name));
    }

    private VfsNode deepCopy(VfsNode source, String newName) {
        VfsNode copy = new VfsNode(newName, source.isDirectory(), source.getContent(), source.getMode());
        for (VfsNode child : source.getChildren().values()) {
            copy.addChild(deepCopy(child, child.getName()));
        }
        return copy;
    }

    public void chmod(String cwd, int mode, String path) {
        get(cwd, path).setMode(mode);
    }

    public void save(Path path) throws IOException {
        Files.writeString(path, toJson(root, 0), StandardCharsets.UTF_8);
    }

    private String toJson(VfsNode node, int level) {
        String indent = "  ".repeat(level);
        String next = "  ".repeat(level + 1);
        StringBuilder sb = new StringBuilder();
        sb.append(indent).append("{\n");
        sb.append(next).append("\"name\": \"").append(escape(node.getName())).append("\",\n");
        sb.append(next).append("\"directory\": ").append(node.isDirectory()).append(",\n");
        sb.append(next).append("\"mode\": ").append(node.getMode());
        if (!node.isDirectory()) {
            sb.append(",\n").append(next).append("\"content_base64\": \"")
              .append(Base64.getEncoder().encodeToString(node.getContent().getBytes(StandardCharsets.UTF_8))).append("\"");
        }
        if (node.isDirectory()) {
            sb.append(",\n").append(next).append("\"children\": [");
            if (!node.getChildren().isEmpty()) {
                sb.append("\n");
                int i = 0;
                for (VfsNode child : node.getChildren().values()) {
                    sb.append(toJson(child, level + 2));
                    if (++i < node.getChildren().size()) sb.append(",");
                    sb.append("\n");
                }
                sb.append(indent).append("  ");
            }
            sb.append("]");
        }
        sb.append("\n").append(indent).append("}");
        return sb.toString();
    }

    private String escape(String value) {
        return value.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    /**
     * Минимальный JSON-парсер без внешних библиотек.
     * Поддерживает объекты, массивы, строки, числа, boolean и null.
     */
    private static class JsonParser {
        private final String s;
        private int i;

        JsonParser(String s) { this.s = s; }

        Object parse() {
            skip();
            Object value = value();
            skip();
            if (i != s.length()) throw new EmulatorException("Некорректный JSON");
            return value;
        }

        private Object value() {
            skip();
            if (i >= s.length()) throw new EmulatorException("Неожиданный конец JSON");
            char c = s.charAt(i);
            if (c == '{') return object();
            if (c == '[') return array();
            if (c == '"') return string();
            if (s.startsWith("true", i)) { i += 4; return true; }
            if (s.startsWith("false", i)) { i += 5; return false; }
            if (s.startsWith("null", i)) { i += 4; return null; }
            return number();
        }

        private Map<String,Object> object() {
            Map<String,Object> m = new LinkedHashMap<>();
            i++; skip();
            if (s.charAt(i) == '}') { i++; return m; }
            while (true) {
                String key = string(); skip();
                expect(':');
                Object val = value();
                m.put(key, val);
                skip();
                if (s.charAt(i) == '}') { i++; break; }
                expect(',');
            }
            return m;
        }

        private List<Object> array() {
            List<Object> list = new ArrayList<>();
            i++; skip();
            if (s.charAt(i) == ']') { i++; return list; }
            while (true) {
                list.add(value());
                skip();
                if (s.charAt(i) == ']') { i++; break; }
                expect(',');
            }
            return list;
        }

        private String string() {
            expect('"');
            StringBuilder b = new StringBuilder();
            while (i < s.length()) {
                char c = s.charAt(i++);
                if (c == '"') return b.toString();
                if (c == '\\') {
                    if (i >= s.length()) throw new EmulatorException("Некорректная строка JSON");
                    char e = s.charAt(i++);
                    switch (e) {
                        case '"': b.append('"'); break;
                        case '\\': b.append('\\'); break;
                        case 'n': b.append('\n'); break;
                        case 'r': b.append('\r'); break;
                        case 't': b.append('\t'); break;
                        default: b.append(e);
                    }
                } else b.append(c);
            }
            throw new EmulatorException("Незакрытая строка JSON");
        }

        private Number number() {
            int start = i;
            while (i < s.length() && "-+0123456789.eE".indexOf(s.charAt(i)) >= 0) i++;
            String n = s.substring(start, i);
            try {
                return n.contains(".") || n.contains("e") || n.contains("E") ? Double.parseDouble(n) : Integer.parseInt(n);
            } catch (NumberFormatException ex) {
                throw new EmulatorException("Некорректное число JSON");
            }
        }

        private void expect(char c) {
            skip();
            if (i >= s.length() || s.charAt(i) != c) throw new EmulatorException("Ожидался символ: " + c);
            i++;
            skip();
        }

        private void skip() {
            while (i < s.length() && Character.isWhitespace(s.charAt(i))) i++;
        }
    }
}
