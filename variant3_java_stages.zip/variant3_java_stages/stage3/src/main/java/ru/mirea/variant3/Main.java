package ru.mirea.variant3;

import java.io.IOException;

/** Точка входа в приложение. */
public class Main {
    public static void main(String[] args) throws Exception {
        Config config = Config.parse(args);
        if (config.debug()) {
            System.out.println("VFS: " + config.vfsPath());
            System.out.println("SCRIPT: " + config.scriptPath());
        }

        Vfs vfs = Vfs.load(config.vfsPath());
        Shell shell = new Shell(vfs);

        if (config.scriptPath() != null) {
            shell.setScriptMode(true);
            try {
                shell.runScript(config.scriptPath());
            } catch (EmulatorException e) {
                System.exit(1);
            }
        } else {
            shell.runInteractive();
        }
    }
}
