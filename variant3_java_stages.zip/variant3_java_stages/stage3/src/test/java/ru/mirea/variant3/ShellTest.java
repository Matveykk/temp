package ru.mirea.variant3;

import org.junit.jupiter.api.Test;
import java.nio.file.Files;
import java.nio.file.Path;
import static org.junit.jupiter.api.Assertions.*;

class ShellTest {
    @Test
    void vfsLoadsAndPathsWork() throws Exception {
        Vfs vfs = Vfs.load(Path.of("vfs/files.json"));
        assertTrue(vfs.get("/", "/docs").isDirectory());
        assertNotNull(vfs.get("/", "/hello.txt"));
    }

    @Test
    void quotedArgumentsAreParsed() {
        VfsNode root = new VfsNode("/", true, "", 755);
        Shell shell = new Shell(new Vfs(root));
        assertDoesNotThrow(() -> shell.executeLine("help"));
    }

    @Test
    void copyAndChmodWork() throws Exception {
        Vfs vfs = Vfs.load(Path.of("vfs/files.json"));
        vfs.copy("/", "/hello.txt", "/copy.txt");
        assertNotNull(vfs.get("/", "/copy.txt"));
        vfs.chmod("/", 600, "/copy.txt");
        assertEquals(600, vfs.get("/", "/copy.txt").getMode());
    }
}
