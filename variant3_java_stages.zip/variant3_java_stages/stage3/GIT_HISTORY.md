# История Git — stage3

0790e29 stage 1: implement REPL
2a87a8d stage 2: add CLI configuration and startup scripts
8348685 stage 3: implement in-memory VFS and vfs-save

Просмотр: git log --oneline --decorate --graph
