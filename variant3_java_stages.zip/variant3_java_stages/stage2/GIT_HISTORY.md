# История Git — stage2

50f2a9b stage 1: implement REPL
0f72e46 stage 2: add CLI configuration and startup scripts

Просмотр: git log --oneline --decorate --graph
