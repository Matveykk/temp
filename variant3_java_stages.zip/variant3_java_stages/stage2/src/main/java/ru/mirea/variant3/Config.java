package ru.mirea.variant3;

import java.nio.file.Path;

/** Этап 2: параметры запуска. */
public record Config(Path vfsPath, Path scriptPath, boolean debug) {
    public static Config parse(String[] args) {
        Path vfs = null, script = null; boolean debug = false;
        for (int i = 0; i < args.length; i++) {
            switch (args[i]) {
                case "--vfs" -> vfs = Path.of(args[++i]);
                case "--script" -> script = Path.of(args[++i]);
                case "--debug" -> debug = true;
                default -> throw new IllegalArgumentException("Unknown parameter: " + args[i]);
            }
        }
        return new Config(vfs, script, debug);
    }
}
