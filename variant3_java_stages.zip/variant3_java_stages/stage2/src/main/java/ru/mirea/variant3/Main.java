package ru.mirea.variant3;

import java.nio.file.Files;

/** Этап 2: запуск с CLI-конфигурацией и стартовым скриптом. */
public class Main {
    public static void main(String[] args) throws Exception {
        Config config = Config.parse(args);
        if (config.debug()) {
            System.out.println("VFS path: " + config.vfsPath());
            System.out.println("Script path: " + config.scriptPath());
        }
        Shell shell = new Shell();
        if (config.scriptPath() != null) {
            for (String line : Files.readAllLines(config.scriptPath())) {
                if (!line.isBlank() && !line.trim().startsWith("#")) {
                    System.out.println("$ " + line);
                    // На этапе 2 команды всё ещё выполняются минимальным REPL-прототипом.
                    java.lang.reflect.Method m = Shell.class.getDeclaredMethod("execute", String.class);
                    m.setAccessible(true);
                    m.invoke(shell, line);
                }
            }
        } else shell.run();
    }
}
