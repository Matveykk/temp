# Variant 3 — UNIX-like Shell Emulator

## Этап 5 — Дополнительные команды

cp и chmod, изменение VFS и сохранение.

Практическая работа, вариант №3.

Проект развивается по пяти этапам:
1. REPL;
2. Config;
3. VFS;
4. Основные команды;
5. Дополнительные команды.

## Сборка

```bash
mvn clean package
```

## Запуск

```bash
java -jar target/variant3-emulator-1.0.0.jar
```

## Конфигурация

```bash
java -jar target/variant3-emulator-1.0.0.jar --vfs vfs/files.json --script scripts/stage5.txt --debug
```

## Команды

`ls`, `ls -l`, `cd`, `tree`, `uname`, `uname -a`, `cp`, `chmod`, `vfs-save`, `help`, `exit`.

Все операции с файлами и каталогами выполняются над виртуальной файловой системой в памяти.
