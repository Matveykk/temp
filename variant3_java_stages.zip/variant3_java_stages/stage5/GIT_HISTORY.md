# История Git — stage5

4207abd stage 1: implement REPL
49a4249 stage 2: add CLI configuration and startup scripts
758d806 stage 3: implement in-memory VFS and vfs-save
3c370fd stage 4: add ls cd tree and uname modes
c64c657 stage 5: add cp and chmod

Просмотр: git log --oneline --decorate --graph
